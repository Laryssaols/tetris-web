const tamanho = document.getElementById("classico");

if (tamanho) {
    
    if (tamanho.classList.contains("classico")) {
        tamanho = 1;
    } else {
        tamanho = 2;
    }
} 